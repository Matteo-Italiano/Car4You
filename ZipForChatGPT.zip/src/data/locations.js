// src/data/locations.js
export const LOCATIONS = [
  "Zürich Flughafen (ZRH)",
  "Genf Flughafen (GVA)",
  "Basel EuroAirport (BSL)",
  "Bern Belp (BRN)",
  "Lugano Agno (LUG)",
  "Zürich HB (City)",
  "Bern Bahnhof (City)",
  "Luzern Bahnhof (City)"
];